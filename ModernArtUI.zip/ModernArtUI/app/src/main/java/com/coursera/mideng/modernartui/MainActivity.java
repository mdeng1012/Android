package com.coursera.mideng.modernartui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends Activity {
    private ArrayList<TextView> rectViews = new ArrayList();
    private int[] colors = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewGroup ll = (ViewGroup) findViewById(R.id.rGroup);
        int count = ll.getChildCount();
        for (int i = 0; i < count; i++) {
            ViewGroup view = (ViewGroup)ll.getChildAt(i);
            for (int j = 0; j < view.getChildCount(); j++) {
                TextView rect = (TextView) view.getChildAt(j);
                int viewId = rect.getId();
                if ( viewId != R.id.grey && viewId != R.id.white ) {
                    rectViews.add(rect);
                }
            }
        }
        colors = new int[rectViews.size()];
        for (int i=0; i < colors.length; i++) {
            colors[i]= ((ColorDrawable)rectViews.get(i).getBackground()).getColor();
        }

        SeekBar seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progress = 0;

            @Override
             public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
                    progress = progresValue;
                    // Toast.makeText(getApplicationContext(), "Changing seekbar's progress at "+progress, Toast.LENGTH_SHORT).show();
                    for (int i=0; i < colors.length; i++) {
                        rectViews.get(i).setBackgroundColor(colors[i] + (int) (colors[i] * progress / 100.0));
                    }
            }

                 @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                     // Toast.makeText(getApplicationContext(), "Started tracking seekbar", Toast.LENGTH_SHORT).show();
                 }

                 @Override
                 public void onStopTrackingTouch(SeekBar seekBar) {
                       //  Toast.makeText(getApplicationContext(), "Stopped tracking seekbar at "+progress, Toast.LENGTH_SHORT).show();
                      }
                 });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            DialogFragment mDialog = AlertDialogFragment.newInstance();

            // Show AlertDialogFragment
            mDialog.show(getFragmentManager(), "Alert");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public static class AlertDialogFragment extends DialogFragment {

        public static AlertDialogFragment newInstance() {
            return new AlertDialogFragment();
        }

        // Build AlertDialog using AlertDialog.Builder
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            return new AlertDialog.Builder(getActivity())
                    .setMessage("Inspired by the works of Modern Art masters such as Piet Mondrian and Ben Nicholson. \n\nClick button to learn more!")

                            // User cannot dismiss dialog by hitting back button
                    .setCancelable(false)

                            // Set up No Button
                    .setNegativeButton("Visit MOMA",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int id) {
                                    ((MainActivity) getActivity())
                                            .dismiss(false);
                                }
                            })

                            // Set up Yes Button
                    .setPositiveButton("Not Now",
                            new DialogInterface.OnClickListener() {
                                public void onClick(
                                        final DialogInterface dialog, int id) {
                                    ((MainActivity) getActivity())
                                            .dismiss(true);
                                }
                            }).create();
        }
    }

    public void dismiss(boolean b) {
        if (b == false) {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://www.moma.org/"));
            startActivity(i);
        }
    }
}
