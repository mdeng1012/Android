package com.coursera.mideng.dailyselfie;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import android.content.Context;
import android.location.Location;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class SelfieViewAdapter extends BaseAdapter {

	private ArrayList<SelfieRecord> list = new ArrayList<SelfieRecord>();
	private static LayoutInflater inflater = null;
	private Context mContext;

	public SelfieViewAdapter(Context context) {
		mContext = context;
		inflater = LayoutInflater.from(mContext);
		load();
	}

	public int getCount() {
		return list.size();
	}

	public Object getItem(int position) {
		return list.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		View newView = convertView;
		ViewHolder holder;

		SelfieRecord curr = list.get(position);

		if (null == convertView) {
			holder = new ViewHolder();
			newView = inflater
					.inflate(R.layout.selfie_record_view, parent, false);
			holder.bitmap = (ImageView) newView.findViewById(R.id.bitmap);
			holder.date = (TextView) newView.findViewById(R.id.date);
			holder.location = (TextView) newView.findViewById(R.id.location);
			newView.setTag(holder);

		} else {
			holder = (ViewHolder) newView.getTag();
		}

		holder.bitmap.setImageBitmap(curr.getBitmap());
		holder.date.setText("Time: " + curr.getDate());
		holder.location.setText("Location: " + curr.getLocation());

		return newView;
	}

	static class ViewHolder {

		ImageView bitmap;
		TextView date;
		TextView location;

	}

	public void add(SelfieRecord listItem) {
		list.add(listItem);
		notifyDataSetChanged();
	}

	public ArrayList<SelfieRecord> getList() {
		return list;
	}

	public void removeAllViews() {
		list.clear();
		this.notifyDataSetChanged();
	}

	public void save() {
		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {

			File outFile = new File(
					mContext.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName);

			try (BufferedWriter br = new BufferedWriter(new FileWriter(outFile))) {
				for (SelfieRecord rc : list) {
					String line = rc.getDate()+":"+rc.getPath();
					br.write(line);
					br.newLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String fileName = "Selfie_Records.txt";
	public void load() {

		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {

			File inFile = new File(
					mContext.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName);

			if (inFile.exists()) {
				try (BufferedReader br = new BufferedReader(new FileReader(inFile))) {
					String line;
					while ((line = br.readLine()) != null) {
						// System.out.println(" -> " + line);
						String[] rec = line.split(":");
						add(new SelfieRecord(rec[0],rec[1]));
					}
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
