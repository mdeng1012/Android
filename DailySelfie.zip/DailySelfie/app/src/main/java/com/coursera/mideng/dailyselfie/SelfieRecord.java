package com.coursera.mideng.dailyselfie;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.util.Log;

public class SelfieRecord {
	private Bitmap mBitmap;
	private String mDate;
	private String mPath;
	private Location mLocation;

	public SelfieRecord(String date, String path) {
		this.mBitmap = getBitMapPic(path);
		this.mDate = date;
		this.mPath = path;
	}
	
	public Bitmap getBitmap() {
		return mBitmap;
	}

	public void setBitmap(Bitmap bitmap) {
		this.mBitmap = bitmap;
	}

	public String getDate() {
		return mDate;
	}

	public void setDate(String date) {
		this.mDate = date;
	}

	public String getPath() {
		return mPath;
	}

	public void setPath(String path) {
		this.mPath = path;
	}

	public void setLocation(Location location) {
		mLocation = location;
	}

	public Location getLocation() {
		return mLocation;
	}


	@Override
	public String toString(){
		return "Path: " + mPath + " Date: " + mDate;
		
	}

	private Bitmap getBitMapPic(String mCurrentPhotoPath) {
		// Get the dimensions of the View
		int targetW = 120; // 160;
		int targetH = 90; // 120;

		// Get the dimensions of the bitmap
		BitmapFactory.Options bmOptions = new BitmapFactory.Options();
		bmOptions.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
		int photoW = bmOptions.outWidth;
		int photoH = bmOptions.outHeight;

		// Determine how much to scale down the image
		int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

		// Decode the image file into a Bitmap sized to fill the View
		bmOptions.inJustDecodeBounds = false;
		bmOptions.inSampleSize = scaleFactor;
		bmOptions.inPurgeable = true;

		return BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
		// mImageView.setImageBitmap(bitmap);
	}
}
